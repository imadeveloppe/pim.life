# Changelog

### 1.1.2 (26.11.2015)
- Handle no-jquery integration in filepicker directive

### 1.1.1 (25.11.2015)
- Bump up [filepicker-js](https://github.com/filepicker/filepicker-js) library version to 2.3.1

### 1.1.0 (04.11.2015)
- Bump up [filepicker-js](https://github.com/filepicker/filepicker-js) library version to 2.2.0

### 1.0.1 (04.10.2015)
- Include filepicker script as bower dependency